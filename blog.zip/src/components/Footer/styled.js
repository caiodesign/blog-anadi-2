import styled from 'styled-components'

export const FooterComponent = styled.div`
    width: 100%;
    border-top: 1px solid #000;
    padding: 10px 5px;
    text-align: center;
    margin: 0;
`