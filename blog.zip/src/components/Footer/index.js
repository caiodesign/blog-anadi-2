import React from 'react'
import { FooterComponent } from './styled'

export default function Footer () {
    return (
        <FooterComponent>
            Footer
        </FooterComponent>
    )
}