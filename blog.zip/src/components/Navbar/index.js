import React from 'react'
import { NavComponent } from './styled'

export default function Navbar () {
    return (
        <NavComponent>
            navbar
        </NavComponent>
    )
}